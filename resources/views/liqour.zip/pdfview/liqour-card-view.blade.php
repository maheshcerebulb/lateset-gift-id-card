@extends('layouts.id-card')
@section('pageTitle', 'GIFT SEZ')
@section('content')

{{-- front start --}}

<div style="margin-top:0px;margin-bottom:0px;border:1px solid black;height: 225px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 5px;float:left; background-color:#FFFEF2;">
    <div style="border:2px solid #9a7f44;">
        <div style>
            <div class="d-flex justify-content-center p-2" style="border-bottom: 2px solid #9a7f44;">
                <img width="60" height="50" src="{{ asset('img/logo.png')}}" alt="">
                <div style="flex: 1;">
                    <p style="padding-top:0pt;padding-left:0pt;text-align: center;margin:0px;">
                        <span style="color:#092752;font-weight: bold;font-size:14px;">
                           LIQOUR ACCESS PERMIT
                        </span>
                    </p>
                    <p style="padding-top: 0pt;text-indent: 0pt;text-align: center;margin:0px;">
                        <span style="color:#092752;font-weight:bold;font-size:8px;padding-top:0;">
                        Permit to consume liqour at F.LIII licence premises
                        </span>
                    </p>
                    <p style="padding-top: 0pt;text-indent: 0pt;text-align: center;margin:0px;">
                        <span style="color:#092752;font-size:8px;">
                            Gift City, Gandhinagar
                        </span>
                    </p>
                </div>
            </div>
        </div>
        <div style="width:100%;padding:5px;display:flex;">
            <div style="flex:1;">
                <table style="color: #231F20;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;width:50%;">Name of Passholder</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ \Illuminate\Support\Str::limit($row->name, 16) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Designation</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ \Illuminate\Support\Str::limit($row->designation, 16) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Company/Organization/Unit Name & Address</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ \Illuminate\Support\Str::limit($row->company_name, 16) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Validity</th>
                            <td>:</td>
                            <td>{{ date('d-m-Y',strtotime($row->expire_date))}}</td>
                        </tr>
                       
                    </tbody>
                </table>
            </div>
            <div style="text-align:center;height: fit-content;">
                <p style="font-size: 7px;margin:5px 0px;">
                   <span class="font-weight-boldest">Sr No. : <span >{{ !empty($row->serial_number) ? $row->serial_number : '' }}</span></span> 
                </p>
                <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/'.$row->image)}}' style="border:1px solid #9a7f44;padding:2px;">
            </div>
        </div>
        <div style="padding:5px;display:flex;">
            <div style="margin-right:0px;padding:0px;">
                <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/qrcode/'.$row->qrcode)}}' style="border:1px solid #9a7f44;padding:2px;">
            </div>
            <div style="align-self:center;flex:1;margin-left:5px;">   
                <table style="color: #231F20;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Name of Authorized Officer</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">Nisarg Acharya</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Signature of Authorized Officer</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">
                                <img width="60" height="30" src="{{ asset('img/nisarg_acharya_signature.png')}}">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
{{-- front end --}}

{{-- back end --}}

<div style="margin-top:0px;margin-bottom:0px;border:1px solid black;height: 225px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 5px;float:left;background-color:#FFFEF2;">
    <div style="border:2px solid #9a7f44;">
        <p style="padding: 3px;text-align: center;margin:0px;">
            <span style="color:#092752;font-weight: bold;font-size:14px;">
                General Instructions
            </span>
        </p>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <ol style="padding: 0px 0 0 10px;font-size:7px;margin:0px;">
            <li> This pass should be worn and displayed on the person of the pass holder while inside the Zone.</li>
            <li> This pass is not transferable</li>
            <li> This pass shall be produced on demand by GIFT SEZ Security and Customs staff</li>
            <li> The pass holder and his vehicle are liable for Security Check at the GIFT SEZ gate</li>
            <li> The loss of this pass shall immediately be reported to the Security Officer, GIFT SEZ</li>
            <li> This pass shall be surrendered to the Security Officer, GIFT SEZ through the Developer/Unit/Contractor on expiry or on the person becoming ineligible for this pass.</li>
        </ol>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <table style="color: #231F20;font-size: 7px;padding: 0px 0px;line-height:12px;width:100%;height: 25px;">
            <tbody>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;width:50%;">Temporary Residential Address</th>
                    <td>:</td>
                    <td style="text-transform:uppercase;width:45%;">{{ \Illuminate\Support\Str::limit($row->temporary_address, 16) }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <table style="color: #231F20;font-size: 7px;padding: 0px 0px;line-height:12px;width:100%;height: 25px;">
            <tbody>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;width:50%;">Permanent Residential Address</th>
                    <td >:</td>
                    <td style="text-transform:uppercase;width:45%;">{{ \Illuminate\Support\Str::limit($row->permanent_address, 16) }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <table style="color: #231F20;font-size: 7px;padding: 0px 0px;line-height:12px;width:100%;height: 25px;">
            <tbody>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;width:50%;">Mobile No. of Permit (In case of loss of Liqour Access Permit)</th>
                    <td style="border-right:2px solid #9a7f44"></td>
                    <td style="text-transform:uppercase;">{{ $row->mobile_number }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

{{-- back end --}}
