

{{-- front start --}}
{{-- <table style="width: 100%;">
    <tr>
        <td style="" width="50%">
            <table autosize="1" style="border:2px solid #B27938;width:100%;" >
                <tr>
                    <td style="text-align:left;padding:0px;width:30%;">
                            <img width="50" height="40" style="margin:5px 0px;" src="{{asset('img/logo.png')}}">
                    </td>
                    <td style="float:left;color:#092752;font-weight: bold;font-size:14px;width:70%;text-align:center;"> 
                            <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;">
                                <span style="color:#092752;font-size:15px;">
                                    LIQOUR ACCESS PERMIT
                                </span>
                            </p>
                            <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;">
                                <span style="color:#092752;font-weight:bold;font-size:8px;padding-top:0;">
                                    Permit to consume liqour at F.LIII licence premises
                                    </span>
                            </p>
                            <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;">
                                <span style="color:#092752;font-size:8px;">
                                    Gift City, Gandhinagar
                                </span>
                            </p>
                            
                            
                    </td>
                </tr>
            </table>
            <table  autosize="1" style="border:2px solid #B27938;width:100%;color: #231F20;font-size:9px;padding: 15px 0px;" >
                <tr>
                    
                    <th style="width:45%;text-align:left;text-transform:uppercase;">Name of Passholder</th>
                    <td style="width:35%;text-align:left">
                                :  Rushabh
                    </td>
                    <td style="width:25%">
                        Sr No. : 0002   
                    </td>
                </tr>
                <tr>
                    
                    <th style="text-align:left;text-transform:uppercase;">DESIGNATION</th>
                    <td>
                        :  Rushabh
                    </td>
                    <td rowspan="3">
                        <img width="50" height="50" src='{{ asset('upload/liqour-application/'.$row->image)}}' style="border:1px solid #B27938;padding:2px;">
                    </td>
                </tr>
                <tr>
                    
                    <th style="text-align:left;text-transform:uppercase;">COMPANY / ORGANIZATION / UNIT</th>

                    <td>
                        : Rushabh
                    </td>
                    
                </tr>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;">VALIDITY</th>
                    
                    <td>
                        : Rushabh
                    </td>
                </tr>
                <tr style="margin:20px 0px;">
                    <td style="padding:2px 5px;">
                        <img width="50" height="50" src='{{ asset('upload/liqour-application/qrcode/'.$row->qrcode)}}' style="border:1px solid #B27938;padding:2px;">
                    </td>
                    <td colspan="3" >
                        <table style="color: #231F20;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                            <tbody>
                                <tr>
                                    <th style="text-align:left;text-transform:uppercase;">Name of Authorized Officer</th>
                                    <td>:</td>
                                    <td style="text-transform:uppercase;">Chetan Verma</td>
                                </tr>
                                <tr>
                                    <th style="text-align:left;text-transform:uppercase;">Signature of Authorized Officer</th>
                                    <td>:</td>
                                    <td style="text-transform:uppercase;">
                                        <img width="60" height="20" src="{{ asset('img/officer_signature.png')}}">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
       </td>
       <td   width="50%">
           <table autosize="1" style="border:2px solid #B27938;width:100%;font-size:14px;vertical-align:top;" >
                <tr style="font-weight:boldest;padding:7px;">
                        <td colspan="3" style="border-bottom:2px solid #B27938;font-size:14px;text-align:center;padding:6px;font-weight:boldest;">
                        General Instructions</td>
                </tr>
               <tr>
                   <td colspan="3" style="border-bottom:2px solid #B27938;font-size:8px;font-weight:bolder;"> 
                       <ol style="font-size:10px;margin:0px;font-weight:boldest;line-height:50px">
                           <li> This pass should be worn and displayed on the person of the pass holder while inside the Zone.</li>
                           <li> This pass is not transferable</li>
                           <li> This pass shall be produced on demand by GIFT SEZ Security and Customs staff</li>
                           <li> The pass holder and his vehicle are liable for Security Check at the GIFT SEZ gate</li>
                           <li> The loss of this pass shall immediately be reported to the Security Officer, GIFT SEZ</li>
                           <li> This pass shall be surrendered to the Security Officer, GIFT SEZ through<br> the Developer/Unit/Contractor on expiry or on the person becoming ineligible for this pass.</li>
                            
                       </ol>
                    </td>
                </tr>
               <tr>
                    <td colspan="3" style="border-bottom:2px solid #B27938;font-size: 9px;">
                        <span style="font-weight:boldest;"> Residential Address :  </span><br>
                        <span>{{ $row->temporary_address }}</span>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="3" style="border-bottom:2px solid #B27938;font-size: 9px;font-weight:boldest;">
                        Permanent Residential Address :  <br> <span>{{ $row->permanent_address }}</span>
                    </td>
                </tr>
                <tr>
                   <td style="width:50%;border-right:2px solid #B27938;font-size: 9px;font-weight:boldest;"> 
                       Mobile No. of Permit (In case of loss of Liqour Access Permit) 
                    </td>
                    
                    <td style="width:50%"> 
                      
                    </td>
                </tr>
               
           </table>
       </td>
   </tr>
   </table> --}}

   
{{-- back end --}}
<style>
    .rounded-image {
        border-radius: 10px; /* Apply border-radius to specific img tags */
    }
    .font-{font-weight: bold}
</style>
<div style="margin-top:0px;margin-bottom:0px;border:2px solid #B27938;height: 200px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 5px;float:left;margin:right:5px; background-color:#FFFEF2;border-radius:7px;">
    <div style="">
        <div style="pedding:1px;">
            <div style="float: left;width:50px;padding:0px 5px;border-right:0.2px solid #9fa09e;">
                <img width="50" height="40" src="{{asset('img/gift_city_logo_svg.svg')}}">
            </div>
           
            <div style="float:left;text-align:left;padding:0px 5px;">
                <p style="padding-top:0pt;padding-left:0pt;margin:0px 0px;">
                    <span style="color:#B27938;font-weight: bold;font-size:20px;">
                       Liqour Access Permit
                    </span>
                </p>
                <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;font-weight:bold;">
                    <span style="font-size:6px;padding-top:0;font-weight:bold;color:#000000;">
                    Permit to consume liqour at F.LIII licence premises, Gift City, Gandhinagar
                    </span>
                </p>
                {{-- <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;">
                    <span style="color:#092752;font-size:7px;">
                        Gift City, Gandhinagar
                    </span>
                </p> --}}
            </div>
        </div>
        <div style="width:100%;padding:0px 0px;display:flex;padding-top:5px;color:#000000;">
            <div style="float:left;width:240px;">
                <table style="color:#000000;font-size: 8px;padding: 0px 0px;line-height:10px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;width:45%;">Name</th>
                            <td>:</td>
                            <td style="text-align:left;width:54%;">{{ \Illuminate\Support\Str::limit($row->name, 100) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:45%;">Designation</th>
                            <td>:</td>
                            <td style="text-align:left;width:54%;">{{ \Illuminate\Support\Str::limit($row->designation, 100) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:45%;">Company / Organization/ Unit Name and Address</th>
                            <td>:</td>
                            <td style="text-align:left;width:54%;">{{ \Illuminate\Support\Str::limit($row->company_name, 100) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:45%;">Validity</th>
                            <td>:</td>
                            <td style="width:54%;">{{ date('d/m/Y',strtotime($row->expire_date))}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div style="margin:0px;padding:0px;color:#000000;">
                <p style="font-size: 8px;margin:2px 0px;">
                    <span ><span style="font-weight:bold;">Sr. No. : </span><span >{{ !empty($row->serial_number) ? $row->serial_number : '' }}</span></span> 
                 </p>
                <div style="margin:0px;padding:0px;border-radius:7px;border:2px solid #B27938;height:50px;width:50px;" >
                    <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/'.$row->image)}}' style="margin:0px;">
                </div>
            </div>

            
            {{-- <div style="">
                <table style="color: #231F20;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;width:50%;">Name of Passholder</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ $row->name }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Designation</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ $row->designation }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Company/Organization/Unit Name & Address</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ $row->company_name }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Validity</th>
                            <td>:</td>
                            <td>{{ date('d-m-Y',strtotime($row->expire_date))}}</td>
                        </tr>
                       
                    </tbody>
                </table>
            </div> --}}
            {{-- <div style="width:80px;">
                <p style="font-size: 7px;margin:5px 0px;">
                   <span style="font-weight:bold;" >Sr No. : <span >{{ !empty($row->serial_number) ? $row->serial_number : '' }}</span></span> 
                </p>
                <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/'.$row->image)}}' style="border:1px solid #B27938;padding:2px;">
            </div> --}}
        </div>
        <div style="padding:0px 0px;color:#000000;">
            <div style="margin-right:0px;padding:0px;float:left;width:22%;align-self:center;">
                <img width="60" height="60" src='{{ asset('upload/liqour-data/liqour-application/qrcode/'.$row->qrcode)}}' style="padding:2px;">   
            </div>
            <div style="align-self:center;margin-left:5px;margin-top:10px;margin-bottom:0px;">   
                <table style="color: #231F20;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;vertical-align:middle;">
                    <tbody>
                        <tr >
                            <th style="text-align:left;width:48%;">Name of Authorized Officer</th>
                            <td style="width: 1%;">:</td>
                            <td style="width:51%;">Nisarg Acharya</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:48%;">Sign of Authorized Officer</th>
                            <td style="width: 1%;">:</td>
                            <td style="width:51%;">
                                <img width="50" height="30" src="{{ asset('img/nisarg_acharya_signature.png')}}">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
{{-- front end --}}

{{-- back end --}}

