<div class="wizard-nav custom-wizard-nav">
    <div class="nav wizard-steps py-2 px-2 py-lg-2 px-lg-2" id="liqour_application_tab">
        <!--begin::Wizard Step 1 Nav-->
        <a class="wizard-step active" id="tab-liqour-application-detail" data-toggle="tab" href="#liqour-application-detail">
            <div class="wizard-label">
                <h3 class="wizard-title">
                <span>1.</span>Applicant Details</h3>
                <div class="wizard-bar"></div>
            </div>
        </a>
        <!--end::Wizard Step 1 Nav-->
        <!--begin::Wizard Step 2 Nav-->
        <a class="wizard-step" id="tab-liqour-application-verify-and-submit-detail" data-toggle="tab" href="#liqour-application-verify-and-submit-detail">
            <div class="wizard-label">
                <h3 class="wizard-title">
                <span>2.</span>Verify And Submit</h3>
                <div class="wizard-bar"></div>
            </div>
        </a>
        <!--end::Wizard Step 2 Nav-->        
    </div>
</div>
@php
			if (isset($ApplicationDetailData)) {
				if(!empty($ApplicationDetailData) && $ApplicationDetailData->mobile_number)
				{
				
						echo "<script>  
							set_country_code('mobile_number','".strtolower($ApplicationDetailData->country_code)."')
							</script>";
				}
				
			}
			
		@endphp