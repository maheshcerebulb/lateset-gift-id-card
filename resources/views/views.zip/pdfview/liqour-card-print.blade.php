@extends('layouts.id-card')
@section('pageTitle', 'GIFT SEZ')
@section('content')
<style>
   @media print {
    @page
   {
    size: 5.5in 8.5in ;
    size: landscape;
  }
        .pagebreak { page-break-before: always; } /* page-break-after works, as well */
        
    }
</style>
{{-- {{dd($row)}} --}}
@php
    $row->name=$row->first_name.' '.$row->last_name;
@endphp
{{-- front start --}}
{{-- 
<div style="margin-top:0px;margin-bottom:0px;border:1px solid black;height: 225px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 5px;float:left; ">
    <div style="border:2px solid #9a7f44;">
        <div style>
            <div class="d-flex justify-content-center p-2" style="border-bottom: 2px solid #9a7f44;">
                <img width="60" height="50" src="{{ asset('img/logo.png')}}" alt="">
                <div style="flex: 1;">
                    <p style="padding-top:0pt;padding-left:0pt;text-align: center;margin:0px;">
                        <span style="color:#092752;font-weight: bold;font-size:14px;">
                           LIQOUR ACCESS PERMIT
                        </span>
                    </p>
                    <p style="padding-top: 0pt;text-indent: 0pt;text-align: center;margin:0px;">
                        <span style="color:#092752;font-weight:bold;font-size:8px;padding-top:0;">
                        Permit to consume liqour at F.LIII licence premises
                        </span>
                    </p>
                    <p style="padding-top: 0pt;text-indent: 0pt;text-align: center;margin:0px;">
                        <span style="color:#092752;font-size:8px;">
                            Gift City, Gandhinagar
                        </span>
                    </p>
                </div>
            </div>
        </div>
        <div style="width:100%;padding:5px;display:flex;">
            <div style="flex:1;">
                <table style="color: #000000;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;width:50%;">Name of Passholder</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ \Illuminate\Support\Str::limit($row->name, 16) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Designation</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ \Illuminate\Support\Str::limit($row->designation, 16) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Company/Organization/Unit Name & Address</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ \Illuminate\Support\Str::limit($row->company_name, 16) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Validity</th>
                            <td>:</td>
                            <td>{{ date('d-m-Y',strtotime($row->expire_date))}}</td>
                        </tr>
                       
                    </tbody>
                </table>
            </div>
            <div style="text-align:center;height: fit-content;">
                <p style="font-size: 7px;margin:5px 0px;">
                   <span class="font-weight-boldest">Sr No. : <span >{{ !empty($row->serial_number) ? $row->serial_number : '' }}</span></span> 
                </p>
                <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/'.$row->image)}}' style="border:1px solid #9a7f44;padding:2px;">
            </div>
        </div>
        <div style="padding:5px;display:flex;">
            <div style="margin-right:0px;padding:0px;">
                <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/qrcode/'.$row->qrcode)}}' style="border:1px solid #9a7f44;padding:2px;">
            </div>
            <div style="align-self:center;flex:1;margin-left:5px;">   
                <table style="color: #000000;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Name of Authorized Officer</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">Nisarg Acharya</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Signature of Authorized Officer</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">
                                <img width="60" height="30" src="{{ asset('img/nisarg_acharya_signature.png')}}">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div> --}}
{{-- front end --}}

{{-- back end --}}
{{-- <div class="pagebreak"> </div>
<div style="margin-top:0px;margin-bottom:0px;border:1px solid black;height: 225px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 5px;float:left;">
    <div style="border:2px solid #9a7f44;">
        <p style="padding: 3px;text-align: center;margin:0px;">
            <span style="color:#092752;font-weight: bold;font-size:14px;">
                General Instructions
            </span>
        </p>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <ol style="padding: 0px 0 0 10px;font-size:7px;margin:0px;">
            <li> This pass should be worn and displayed on the person of the pass holder while inside the Zone.</li>
            <li> This pass is not transferable</li>
            <li> This pass shall be produced on demand by GIFT SEZ Security and Customs staff</li>
            <li> The pass holder and his vehicle are liable for Security Check at the GIFT SEZ gate</li>
            <li> The loss of this pass shall immediately be reported to the Security Officer, GIFT SEZ</li>
            <li> This pass shall be surrendered to the Security Officer, GIFT SEZ through the Developer/Unit/Contractor on expiry or on the person becoming ineligible for this pass.</li>
        </ol>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <table style="color: #000000;font-size: 7px;padding: 0px 0px;line-height:12px;width:100%;height: 25px;">
            <tbody>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;width:50%;">Temporary Residential Address</th>
                    <td>:</td>
                    <td style="text-transform:uppercase;width:45%;">{{ \Illuminate\Support\Str::limit($row->temporary_address, 16) }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <table style="color: #000000;font-size: 7px;padding: 0px 0px;line-height:12px;width:100%;height: 25px;">
            <tbody>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;width:50%;">Permanent Residential Address</th>
                    <td >:</td>
                    <td style="text-transform:uppercase;width:45%;">{{ \Illuminate\Support\Str::limit($row->permanent_address, 16) }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div style="border:2px solid #9a7f44;border-top:0px;">
        <table style="color: #000000;font-size: 7px;padding: 0px 0px;line-height:12px;width:100%;height: 25px;">
            <tbody>
                <tr>
                    <th style="text-align:left;text-transform:uppercase;width:50%;">Mobile No. of Permit (In case of loss of Liqour Access Permit)</th>
                    <td style="border-right:2px solid #9a7f44"></td>
                    <td style="text-transform:uppercase;">{{ $row->mobile_number }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div> --}}

{{-- back end --}}


{{-- rushabh pdf html code --}}


<div style="margin-top:0px;margin-bottom:0px;border:2px solid #B27938;height: 200px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 5px;float:left;margin:right:5px; border-radius:7px;">
    <div style="">
        <div style="padding:1px;">
            <div style="float: left;width:60px;padding:0px 5px;border-right:0.2px solid #9fa09e;">
                <img width="50" height="40" src="{{asset('img/gift_city_logo_svg.svg')}}">
            </div>
           
            <div style="float:left;text-align:left;padding:0px 5px;">
                <p style="padding-top:0pt;padding-left:0pt;margin:0px 0px;">
                    <span style="color:#B27938;font-size:20px;">
                       Liqour Access Permit
                    </span>
                </p>
                <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;font-weight:bolder;">
                    <span style="font-size:6px;padding-top:0;font-weight:bold;color:#000000;">
                    Permit to consume liqour at F.LIII licence premises, Gift City, Gandhinagar
                    </span>
                </p>
                {{-- <p style="padding-top: 0pt;text-indent: 0pt;margin:0px;">
                    <span style="color:#092752;font-size:7px;">
                        Gift City, Gandhinagar
                    </span>
                </p> --}}
            </div>
        </div>
        <div style="width:100%;padding:5px 0px;display:flex;color:#000000;">
            <div style="float:left;width:250px;">
                <table style="color:#000000;font-size: 9px;padding: 0px 0px;line-height:10px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;width:50%;">Name</th>
                            <td>:</td>
                            <td style="text-align:left;width:49%;font-weight: 600;">{{ \Illuminate\Support\Str::limit($row->name, 100) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:50%;">Designation</th>
                            <td>:</td>
                            <td style="text-align:left;width:49%;font-weight: 600;">{{ \Illuminate\Support\Str::limit($row->designation, 100) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:50%;">Company / Organization/ Unit Name and Address</th>
                            <td>:</td>
                            <td style="text-align:left;width:49%;font-weight: 600;">{{ \Illuminate\Support\Str::limit($row->company_name, 100) }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:50%;">Validity</th>
                            <td>:</td>
                            <td style="width:49%;font-weight: 600;">{{ date('d/m/Y',strtotime($row->expire_date))}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div style="margin:0px;padding:0px;color:#000000;flex: 1;">
                <p style="font-size: 8px;margin:2px 0px;">
                    <span ><span style="font-weight:bolder;">Sr. No. : </span><span >{{ !empty($row->serial_number) ? $row->serial_number : '' }}</span></span> 
                 </p>
                <div style="margin:0px;padding:0px;border-radius:7px;height:50px;width:50px;" >
                    <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/'.$row->image)}}' style="margin:0px;border:2px solid #B27938;border-radius:5px;">
                </div>
            </div>

            
            {{-- <div style="">
                <table style="color: #000000;font-size: 8px;padding: 0px 0px;line-height:12px;width:100%;">
                    <tbody>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;width:50%;">Name of Passholder</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ $row->name }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Designation</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ $row->designation }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Company/Organization/Unit Name & Address</th>
                            <td>:</td>
                            <td style="text-transform:uppercase;">{{ $row->company_name }}</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;text-transform:uppercase;">Validity</th>
                            <td>:</td>
                            <td>{{ date('d-m-Y',strtotime($row->expire_date))}}</td>
                        </tr>
                       
                    </tbody>
                </table>
            </div> --}}
            {{-- <div style="width:80px;">
                <p style="font-size: 7px;margin:5px 0px;">
                   <span style="font-weight:bold;" >Sr No. : <span >{{ !empty($row->serial_number) ? $row->serial_number : '' }}</span></span> 
                </p>
                <img width="50" height="50" src='{{ asset('upload/liqour-data/liqour-application/'.$row->image)}}' style="border:1px solid #B27938;padding:2px;">
            </div> --}}
        </div>
        <div style="padding:0px 0px;color:#000000;display: flex;">
            <div style="margin-right:0px;padding:0px;float:left;width:20%;align-self:center;">
                <img width="60" height="60" src='{{ asset('upload/liqour-data/liqour-application/qrcode/'.$row->qrcode)}}' style="padding:2px;">
            </div>
            <div style="align-self:center;margin-left:5px;margin-top:10px;margin-bottom:0px;width:80%;">   
                <table style="color: #000000;font-size: 9px;padding: 0px 0px;line-height:12px;width:100%;vertical-align:middle;">
                    <tbody>
                        <tr >
                            <th style="text-align:left;width:54%;">Name of Authorized Officer</th>
                            <td style="width: 1%;">:</td>
                            <td style="width:45%;font-weight: 600;">Nisarg Acharya</td>
                        </tr>
                        <tr>
                            <th style="text-align:left;width:54%;">Sign of Authorized Officer</th>
                            <td style="width: 1%;">:</td>
                            <td style="width:45%;">
                                <img width="50" height="30" src="{{ asset('img/nisarg_acharya_signature.png')}}">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="pagebreak"> </div>
<div style="margin-top:0px;margin-bottom:0px;border:2px solid #B27938;height: 200px;width: 320px;box-sizing: border-box;overflow: hidden;position: relative;padding: 0px;border-radius:5px;">
    <div style="padding:0px 5px;">
        <p style="margin:0px;">
            <span style="color:#000000;font-weight: bold;font-size:12px;">
                General Instruction
            </span>
        </p>
    </div>
    <div style="border-top:0px;line-height:10px;color:#000000;padding-left:10px;font-size:7px;font-weight: 500;">
        <ul style="padding: 0px 5px 4px 9px;margin:0px;" class="custom-list">
            <li> This permit should be displayed while entering the Wine and Dine Facility Area 
                holding F. L. III license in GIFT City.</li>
            <li> This permit is not transferable.</li>
            <li> This permit shall be produced on demand by concerned officials.</li>
            <li> The loss of this permit shall immediately be reported to the Issuing Authority.</li>
            <li> The Card holder is bound to follow the provisions of the Gujarat Prohibition Act, 
                1949, the rules, regulations and orders made thereunder and conditions. Any 
                breach thereof by the Card holder shall be dealt with in accordance with 
                provisions of law.
            </li>
        </ul>
    </div>
    <div style="border-top:2px solid #B27938;height:34px;color:#000000;">
        <table style="text-align:left;color: #000000;font-size: 9px;padding: 0px 0px;width:100%;padding:0px 5px;line-height: 10px;">
            <tbody>
                <tr style="font-size: 9px;">
                    <th style="text-align:left;width:50% !important;vertical-align:top;font-size: 9px;">Temporary Residential Address :</th>
                    <td style="text-align:left;vertical-align:top;font-size: 9px;">
                        <span style="word-wrap: break-word;font-weight: 500;">
                            {{ \Illuminate\Support\Str::limit($row->temporary_address, 100) }}
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div style="border-top:2px solid #B27938;height:34px;color:#000000;">
        <table style="text-align:left;color: #000000;font-size: 9px !important;padding: 0px 0px;width:100%;padding:0px 5px;line-height: 10px;">
            <tbody>
                <tr>
                    <th style="text-align:left;width:50% !important;vertical-align:top;font-size: 9px;">Permanent Residential Address :</th>
                    <td style="text-align:left;vertical-align:top;font-size: 9px;">
                        <span style="word-wrap: break-word;font-weight: 500;">
                            {{ \Illuminate\Support\Str::limit($row->permanent_address, 100) }}
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div style="border-top:2px solid #B27938;color:#000000;">
        <table style="color: #000000;font-size: 9px;padding: 0px 0px;line-height:12px;width:100%;padding:0px 5px;line-height: 10px;">
            <tbody>
                <tr>
                    <th style="text-align:left;width:42% !important;font-size: 9px;">Mobile No. of Permit Holder : </th>
                    <td style="font-size: 9px;font-weight: 500;">{{ !empty($row->dial_code) ? '+'.$row->dial_code.'-' : '' }}{{ $row->mobile_number }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>